<style>
	a {
		color: black;
	}
		a:hover {
			color: white;
		}
</style>

<table class=about-table>
				<td>
				<div class="center-content">
					<div class="rotating-gradient">
						<a alt="Printing" href="<?php echo base_url('produk/printing'); ?>"><img src="/storage/app/public/images/logo/logo-sm.png"></a>
					</div>
					<a alt="Printing" href="<?php echo base_url('produk/printing'); ?>"><h1>About Us</h1></a>
				</div>
				
				</td>
			
				<td>
				<div class="center-content">
					<div class="rotating-gradient">
						<a alt="Digital Ads" href="<?php echo base_url('produk/interior'); ?>"><img src="/storage/app/public/images/logo/logo-sm.png"></a>
					</div>
					<a alt="Printing" href="<?php echo base_url('produk/interior'); ?>"><h1>Digital Ad</h1></a>
				</div>
				
				</td>

				<td>
				<div class="center-content">
					<div class="rotating-gradient">
						<a alt="Media Sosial" href="<?php echo base_url('produk/baliho'); ?>"><img src="/storage/app/public/images/logo/logo-sm.png"></a>
					</div>
					<a alt="Printing" href="<?php echo base_url('produk/baliho'); ?>"><h1>Social Media</h1></a>
				</div>
				</td>
			
			
	</table>
