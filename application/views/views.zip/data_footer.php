   <p>
   <em>&copy; <script>document.write( new Date().getFullYear() );</script> </em>
</body>
</html>
