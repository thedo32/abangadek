<style>
	a:hover {
        color: blue !important;
    }

/* Shake animation */
    @keyframes shake {
        0% { transform: translate(0); }
        25% { transform: translate(-10px, 0); }
        50% { transform: translate(10px, 0); }
        75% { transform: translate(-10px, 0); }
        100% { transform: translate(10px); }
    }

    /* Initial style for about-title */
    #about-title {
        font-size: 1.5em;/* 1.5 times larger */
        display: block;
    }

    /* close to navbar style */
    .shakes-about {
        font-size: 1em; /* Normal size */
        animation: shake 10s ease infinite; /* Add shake animation */
    }
    
    /* Stop shaking when hovered */
    #about-title:hover {
        animation: none;
    }
</style>
<div class=texts-container-cl-home>
	<h1><a id="about-title" style="color:white;" href="<?php echo base_url('about'); ?>">TENTANG KAMI</a></h1>
</div>

<div class=post-container-3>
	<iframe width="640" height="400" src="https://www.youtube.com/embed/3zA7px2VzSU?si=t0kcxa95YN3kuCi1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
</div>
<div class=post-container-4>
		<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d997.3308637947259!2d100.3594215!3d-0.9024206!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2fd4b8ba87c16e81%3A0xbc3c5353edbd8997!2sAbang%20adek%20advertising!5e0!3m2!1sen!2sid!4v1726112265229!5m2!1sen!2sid" width="640" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></iframe>
</div>
<br>



<script>
 function adjustAboutTitle() {
    const aboutTitle = document.getElementById('about-title');
    const fixNavbar = document.querySelector('.fix-navbar');
    const aboutSection = document.querySelector('.texts-container-cl-home');

    const navbarBottom = fixNavbar.getBoundingClientRect().bottom;
    const aboutTop = aboutSection.getBoundingClientRect().top;

    // Calculate absolute distanceabout and make sure it's a whole number
    const distanceabout = Math.floor(Math.abs(aboutTop - navbarBottom));

    // Log the distanceabout for debugging
    //console.log('Distance About:', distanceabout);

    // Check if the distanceabout is less than a threshold
    if (distanceabout > 1400) {
        // Close to navbar: apply shaking and reset to smaller font size
        aboutTitle.classList.add('shakes-about');
        aboutTitle.style.fontSize = '1em'; // Normal size
    } else {
        // Far from navbar: enlarge and stop shaking
        aboutTitle.classList.remove('shakes-about');
        aboutTitle.style.fontSize = '1.5em'; // Enlarge font size
    }
}

// Trigger the font size and animation change on scroll
window.addEventListener('scroll', adjustAboutTitle);

</script>


