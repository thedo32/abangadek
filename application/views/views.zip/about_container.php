<br>
<div class=post-container-3>
	<iframe width="640" height="400" src="https://www.youtube.com/embed/3zA7px2VzSU?si=t0kcxa95YN3kuCi1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
</div>
<div class=post-container-4>
		<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d997.3308637947259!2d100.3594215!3d-0.9024206!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2fd4b8ba87c16e81%3A0xbc3c5353edbd8997!2sAbang%20adek%20advertising!5e0!3m2!1sen!2sid!4v1726112265229!5m2!1sen!2sid" width="640" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></iframe>
</div>
<br>
