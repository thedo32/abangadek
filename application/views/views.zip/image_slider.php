
<div class="slideshow-container-img">    
    <!-- <div class="prev" onclick="plusSlides(-1)">&#10094;</div>
    <div class="next" onclick="plusSlides(1)">&#10095;</div> -->
	
	<img src="<?php echo base_url ("/storage/app/public/images/bg/slider_bg.jpg");?>" class=foreground-img>
	

    <div class="mySlidesImg">
        <img  src="<?php echo base_url ("/storage/app/public/images/slider/1.jpg");?>"  style="width:100vw;"><br>
    
    </div>

    <div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/2.jpg");?>" style="width:100vw;"><br>
    
    </div>

    <div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/3.jpg");?>" style="width:100vw;"><br>
    
    </div>

    <div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/4.jpg");?>" style="width:100vw;"><br>
    
    </div>

	<div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/5.jpg");?>" style="width:100vw;"><br>
   
    </div>

    <div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/6.jpg");?>" style="width:100vw;"><br>
   
    </div>
	<div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/7.jpg");?>" style="width:100vw;"><br>
    
	</div>
	<div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/8.jpg");?>" style="width:100vw;"><br>
    
    </div>
    <div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/9.jpg");?>" style="width:100vw;"><br>
    
    </div>
	
    <div class="mySlidesImg">
        <img src="<?php echo base_url ("/storage/app/public/images/slider/10.jpg");?>" style="width:100vw;"><br>
   
    </div>

 </div>
 <br><br>
<script>
    var slideImgIndex = 0;
    var slides = document.getElementsByClassName("mySlidesImg");
    showSlidesImg();
</script>


