<!DOCTYPE html>
<html>
        <head>
                <title>News Website</title>
				<text type="text/css">




				</style>

        </head>
        <body>

                <h1><?php echo $title; ?></h1>
