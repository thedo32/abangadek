		<div style="margin-left:2%;">
		<h4>Legenda: </h4>
		<table>
			<td>
				<h5><img src="/icon/icon-marker.png" style="width:80px;"> Baliho Satu Sisi</h5>
			</td>
			<td>
				<img src="/icon/icon-marker-second.png" style="width:80px;">
			</td>
			<td>
				<img src="/icon/icon-marker-second.png" style="width:80px;">
			</td>
			<td>
				<img src="/icon/icon-marker-second.png" style="width:80px;">
			</td>
			<td>
				<h5><img src="/icon/icon-marker-first.png" style="width:80px;"> Baliho Dua Sisi</h5>
			</td>
		</table>
		</div>
