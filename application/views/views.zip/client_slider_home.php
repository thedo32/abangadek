<style>
/* Shake animation */
    @keyframes shake {
        0% { transform: translate(0); }
        25% { transform: translate(-10px, 0); }
        50% { transform: translate(10px, 0); }
        75% { transform: translate(-10px, 0); }
        100% { transform: translate(10px); }
    }

    /* Initial style for client-title */
    #client-title {
        font-size: 1.5em;/* 1.5 times larger */
        display: block;
    }

    /* close to navbar style */
    .shakes-client {
        font-size: 1em; /* Normal size */
        animation: shake 10s ease infinite; /* Add shake animation */
    }
    
    /* Stop shaking when hovered */
    #client-title:hover {
        animation: none;
    }
</style>


<div class=texts-container-cl-home>
	<h1><a id="client-title" href="<?php echo base_url('client'); ?>">CLIENT KAMI</a></h1>
	<a href="<?php echo base_url('client'); ?>"><img src="/storage/app/public/images/logo/client.jpg" class=image-container-cl-home></a>
</div>

<script>
 function adjustClientTitle() {
    const clientTitle = document.getElementById('client-title');
    const fixNavbar = document.querySelector('.fix-navbar');
    const clientSection = document.querySelector('.texts-container-cl-home');

    const navbarBottom = fixNavbar.getBoundingClientRect().bottom;
    const clientTop = clientSection.getBoundingClientRect().top;

    // Calculate absolute distanceclient and make sure it's a whole number
    const distanceclient = Math.floor(Math.abs(clientTop - navbarBottom));

    // Log the distanceclient for debugging
    //console.log('Distance Client:', distanceclient);

    // Check if the distanceclient is less than a threshold
    if (distanceclient > 800) {
        // Close to navbar: apply shaking and reset to smaller font size
        clientTitle.classList.add('shakes-client');
        clientTitle.style.fontSize = '1em'; // Normal size
    } else {
        // Far from navbar: enlarge and stop shaking
        clientTitle.classList.remove('shakes-client');
        clientTitle.style.fontSize = '1.5em'; // Enlarge font size
    }
}

// Trigger the font size and animation change on scroll
window.addEventListener('scroll', adjustClientTitle);

</script>

