<div class= containers>
<div class=texts-container-hm>
		<br><br>
		<div style="color:white;">
			<h2>Kami Hadir Untuk Anda...!</h2> <h1>Bukan Sekedar Perusahaan Periklanan</h1>
		</div>
		<img src="/storage/app/public/images/logo/team.jpg" <div class=image-container-hm>
</div>

	
</div>


